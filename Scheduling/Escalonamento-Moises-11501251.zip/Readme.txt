Executar o arquivo main.py
ex.: python main.py
-Mantenha os dois arquivos .py juntos
-ao iniciar digite o nome do caminho + o nome do arquivo e imediatamente ser� processado